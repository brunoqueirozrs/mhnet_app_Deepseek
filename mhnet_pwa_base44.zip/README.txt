MHNET PWA - Base44 style
Files:
- index.html
- styles.css
- app.js
- service-worker.js
- manifest.json

Instructions:
1) Replace API variable in app.js with your WebApp URL (Apps Script deploy URL).
2) Upload the folder 'Rotas_KML' in Drive is handled by backend.
3) Deploy the web app (Apps Script) and test endpoints.
4) Serve this folder via static hosting or open index.html locally (some features like service worker require HTTPS).
